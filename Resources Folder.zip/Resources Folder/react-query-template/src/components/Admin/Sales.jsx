import React from "react";

const Sales = () => {
    return <h3>Admin Sales Page</h3>;
};

export default Sales;
