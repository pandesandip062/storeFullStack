import React from "react";

const Products = () => {
    return (
        <div>
            <h2>Products</h2>
        </div>
    );
};

export default Products;
