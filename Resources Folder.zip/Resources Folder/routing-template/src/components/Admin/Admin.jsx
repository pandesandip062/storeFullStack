import React from "react";

const Admin = () => {
    return (
        <div>
            <h2>Admin Panel</h2>
        </div>
    );
};

export default Admin;
