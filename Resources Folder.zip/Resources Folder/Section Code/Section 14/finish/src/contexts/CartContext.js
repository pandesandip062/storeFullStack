import { createContext } from "react";

const CartContext = createContext(null);

export default CartContext;
