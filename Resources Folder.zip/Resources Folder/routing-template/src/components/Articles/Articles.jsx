import React from "react";

const Articles = () => {
    return (
        <div>
            <h2>
                Articles
                <p>SortBy: Category:</p>
            </h2>
        </div>
    );
};

export default Articles;
