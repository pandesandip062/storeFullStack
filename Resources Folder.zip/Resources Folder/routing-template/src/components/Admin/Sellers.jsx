import React from "react";

const Sellers = () => {
    return <h3>Admin Sellers Page</h3>;
};

export default Sellers;
